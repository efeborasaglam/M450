﻿namespace M320_SmartHome {
    public struct RgbColor {
        public int Red;
        public int Green;
        public int Blue;
    }
}
