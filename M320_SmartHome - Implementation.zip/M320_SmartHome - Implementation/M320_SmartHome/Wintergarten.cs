﻿namespace M320_SmartHome {
    public class Wintergarten : Zimmer {
        public double Sonneneinstrahlung { get; set; }
        public Wintergarten() : base ("Wintergarten") { }

    }
}
