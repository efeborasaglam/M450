﻿namespace M320_SmartHome {
    public enum KochherdStatus {
        Aus,
        Ein,
        AusAberNochWarm
    }
}
