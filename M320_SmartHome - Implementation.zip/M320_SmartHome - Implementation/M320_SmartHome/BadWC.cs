﻿namespace M320_SmartHome {
    public class BadWC : Zimmer {
        public double Feuchtigkeit { get; set; }
        public BadWC() : base("BadWC") { }
    }
}
