using System;
using M320_SmartHome;
using NUnit.Framework;

namespace M320_SmartHome.Tests
{
    [TestFixture]
    public class MarkisensteuerungTests
    {
        [Test]
        public void Markise_FaehrtAusBeiHoherTemperaturUndKeinRegen()
        {
            // Arrange
            var zimmer = new Wintergarten { TemperaturVorgabe = 22 };
            var markise = new Markisensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30, Regen = false };

            // Act
            markise.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Markise wird ausgefahren.");
        }

        [Test]
        public void Markise_FaehrtEinBeiRegen()
        {
            // Arrange
            var zimmer = new Wintergarten { TemperaturVorgabe = 22 };
            var markise = new Markisensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30, Regen = true };

            // Act
            markise.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Markise wird eingefahren, da es regnet.");
        }

        [Test]
        public void Markise_BleibtEingefahrenBeiTieferTemperatur()
        {
            // Arrange
            var zimmer = new Wintergarten { TemperaturVorgabe = 22 };
            var markise = new Markisensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 15, Regen = false };

            // Act
            markise.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Markise bleibt eingefahren bei niedriger Temperatur.");
        }
    }
}
