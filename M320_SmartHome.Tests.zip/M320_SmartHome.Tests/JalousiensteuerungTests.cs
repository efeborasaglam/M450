using System;
using M320_SmartHome;
using NUnit.Framework;

namespace M320_SmartHome.Tests
{
    [TestFixture]
    public class JalousiensteuerungTests
    {
        [Test]
        public void Jalousie_SchliesstBeiHoherTemperaturUndLeeremZimmer()
        {
            // Arrange
            var zimmer = new Kueche { TemperaturVorgabe = 22, PersonenImZimmer = false };
            var jalousie = new Jalousiensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30 };

            // Act
            jalousie.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Jalousie wird geschlossen.");
        }

        [Test]
        public void Jalousie_OeffnetBeiTiefentemperaturUndLeeremZimmer()
        {
            // Arrange
            var zimmer = new Kueche { TemperaturVorgabe = 22, PersonenImZimmer = false };
            var jalousie = new Jalousiensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 15 };

            // Act
            jalousie.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Jalousie wird geöffnet.");
        }

        [Test]
        public void Jalousie_BleibtOffenBeiHoherTemperaturMitPerson()
        {
            // Arrange
            var zimmer = new Kueche { TemperaturVorgabe = 22, PersonenImZimmer = true };
            var jalousie = new Jalousiensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30 };

            // Act
            jalousie.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Jalousie bleibt offen, da Personen im Zimmer sind.");
        }

        [Test]
        public void Jalousie_OeffnetBeiTieferTemperaturMitPerson()
        {
            // Arrange
            var zimmer = new Kueche { TemperaturVorgabe = 22, PersonenImZimmer = true };
            var jalousie = new Jalousiensteuerung(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 15 };

            // Act
            jalousie.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(true, "Jalousie wird geöffnet.");
        }
    }
}