using System;
using M320_SmartHome;
using NUnit.Framework;

namespace M320_SmartHome.Tests
{
    [TestFixture]
    public class WohnungGrenzwertTests
    {
        private Wohnung wohnung;

        [SetUp]
        public void SetUp()
        {
            var wettersensor = new Wettersensor();
            wohnung = new Wohnung(wettersensor);

            // Temperaturvorgaben für alle Zimmer setzen
            wohnung.SetTemperaturvorgabe("BadWC", 22);
            wohnung.SetTemperaturvorgabe("Kueche", 22);
            wohnung.SetTemperaturvorgabe("Schlafen", 19);
            wohnung.SetTemperaturvorgabe("Wohnen", 22);
            wohnung.SetTemperaturvorgabe("Wintergarten", 20);
        }

        [TestCase(-16)]
        [TestCase(-15)]
        [TestCase(-14)]
        public void Wohnung_VerarbeitetMinimaleTemperaturGrenzen(int aussentemperatur)
        {
            // Arrange
            var wetterdaten = new Wetterdaten
            {
                Aussentemperatur = aussentemperatur,
                Regen = false,
                Windgeschwindigkeit = 10
            };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass($"Die Wetterdaten mit einer Temperatur von {aussentemperatur}°C wurden erfolgreich verarbeitet.");
        }

        [TestCase(34)]
        [TestCase(35)]
        [TestCase(36)]
        public void Wohnung_VerarbeitetMaximaleTemperaturGrenzen(int aussentemperatur)
        {
            // Arrange
            var wetterdaten = new Wetterdaten
            {
                Aussentemperatur = aussentemperatur,
                Regen = false,
                Windgeschwindigkeit = 10
            };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass($"Die Wetterdaten mit einer Temperatur von {aussentemperatur}°C wurden erfolgreich verarbeitet.");
        }
    }
}
