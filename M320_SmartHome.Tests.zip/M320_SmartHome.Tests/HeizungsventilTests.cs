using System;
using M320_SmartHome;
using NUnit.Framework;

namespace M320_SmartHome.Tests
{
    [TestFixture]
    public class HeizungsventilTests
    {
        [Test]
        public void Heizungsventil_OeffnetBeiNiedrigerTemperatur()
        {
            // Arrange
            var zimmer = new BadWC { TemperaturVorgabe = 22 };
            var heizungsventil = new Heizungsventil(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 18 };

            // Act
            heizungsventil.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(heizungsventil, Is.Not.Null);
        }

        [Test]
        public void Heizungsventil_SchliesstBeiHoherTemperatur()
        {
            // Arrange
            var zimmer = new BadWC { TemperaturVorgabe = 22 };
            var heizungsventil = new Heizungsventil(zimmer);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 25 };

            // Act
            heizungsventil.VerarbeiteWetterdaten(wetterdaten);

            // Assert
            Assert.That(heizungsventil, Is.Not.Null);
        }
    }
}
