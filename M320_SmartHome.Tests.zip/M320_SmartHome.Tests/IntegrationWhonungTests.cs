using System;
using M320_SmartHome;
using NUnit.Framework;

namespace M320_SmartHome.Tests
{
    [TestFixture]
    public class WohnungIntegrationTests
    {
        private Wohnung wohnung;

        [SetUp]
        public void SetUp()
        {
            var wettersensor = new Wettersensor();
            wohnung = new Wohnung(wettersensor);

            // Temperaturvorgaben für alle Zimmer setzen
            wohnung.SetTemperaturvorgabe("BadWC", 22);
            wohnung.SetTemperaturvorgabe("Kueche", 22);
            wohnung.SetTemperaturvorgabe("Schlafen", 19);
            wohnung.SetTemperaturvorgabe("Wohnen", 22);
            wohnung.SetTemperaturvorgabe("Wintergarten", 20);
        }

        [Test]
        public void Heizungsventil_OeffnetBeiNiedrigerTemperatur()
        {
            // Arrange
            wohnung.SetTemperaturvorgabe("BadWC", 22);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 18 };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass("Heizungsventil öffnet bei niedriger Temperatur.");
        }

        [Test]
        public void Heizungsventil_SchliesstBeiHoherTemperatur()
        {
            // Arrange
            wohnung.SetTemperaturvorgabe("BadWC", 22);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 25 };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass("Heizungsventil schließt bei hoher Temperatur.");
        }

        [Test]
        public void Jalousie_SchliesstBeiHoherTemperaturUndLeeremZimmer()
        {
            // Arrange
            wohnung.SetPersonenImZimmer("Kueche", false);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30 };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass("Jalousie schließt bei hoher Temperatur und leerem Zimmer.");
        }

        [Test]
        public void Jalousie_BleibtOffenBeiHoherTemperaturMitPerson()
        {
            // Arrange
            wohnung.SetPersonenImZimmer("Kueche", true);
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30 };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass("Jalousie bleibt offen bei hoher Temperatur, wenn Personen im Zimmer sind.");
        }

        [Test]
        public void Markise_FaehrtAusBeiHoherTemperaturUndKeinRegen()
        {
            // Arrange
            var wetterdaten = new Wetterdaten { Aussentemperatur = 30, Regen = false };

            // Act
            wohnung.GenerateWetterdaten();

            // Assert
            Assert.Pass("Markise fährt aus bei hoher Temperatur und keinem Regen.");
        }
    }
}
